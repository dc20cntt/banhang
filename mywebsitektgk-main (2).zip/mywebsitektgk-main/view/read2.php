<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
     <meta name="viewport" container="width=device-width, initial-scale=1.0"> 
    <title>Anime</title>
    <link rel="stylesheet" type="text/css" href="../css/test.css">
    <link rel="stylesheet" type="text/css" href="../css/view.css">    
    <link rel="stylesheet" href="https://www.markuptag.com/bootstrap/5/css/bootstrap.min.css" />
    <link rel="icon" type="image/x-icon" href="../images/logoo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
  
    </style>
    </head>
    <body>
      <header>
        <div class="logo">
        <img  src="../images/icon123.png" alt="">
        <h1>  
            WIBU.anime 
         </h1>
        </div>
        <div class="search-container">
          <form action="/action_page.php">
            <input type="text" placeholder="Search.." name="search">
            <button type="submit"><i class="fa fa-search"></i></button>
          </form>
        </div>         
          </div>         
        </div>
        </div>
    </header>
    <strong>
      <div style="width:70% ; margin-left:15%;margin-right:15%;">
      <nav aria-label="breadcrumb" >
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="../index.php"><i class="fa fa-home fa-lg"></i>Home</a></li>
          <li class="breadcrumb-item"><a href="../view/onepiece.php">Đọc Truyện</a></li>
          <li class="breadcrumb-item active" aria-current="page">Chapter</li>
        </ol>
      </nav>
          </div>
 </strong>
    <h2>CHAPTER 43 - One Piece</h2>
    <div class="hhh">
    <button type="button" class="btn btn-outline-primary"><a href=""><-Chap trước</a></button>
    <button type="button" class="btn btn-outline-primary"><a href="read.php">Chap sau-></a></button>
    </div>
     <div>
    <img src="../images/001.jpg" alt="001" style="width:60% ; margin-left:20%;margin-right:20%;">
    <div>
    <img src="../images/002.jpg" alt="002"style="width:60% ; margin-left:20%;margin-right:20%;">
    </div>
    <div>
    <img src="../images/003.jpg" alt="003" style="width:60% ; margin-left:20%;margin-right:20%;">
     </div> 
     <div>
    <img src="../images/004.jpg" alt="003" style="width:60% ; margin-left:20%;margin-right:20%;">
     </div> 
     <div>
    <img src="../images/005.jpg" alt="003" style="width:60% ; margin-left:20%;margin-right:20%;">
     </div> 
     <div>
    <img src="../images/005.jpg" alt="003" style="width:60% ; margin-left:20%;margin-right:20%;">
     </div> 
     <div>
    <img src="../images/006.jpg" alt="003" style="width:60% ; margin-left:20%;margin-right:20%;">
     </div> 
     <div>
    <img src="../images/007.jpg" alt="003" style="width:60% ; margin-left:20%;margin-right:20%;">
     </div> 
     <div>
    <img src="../images/008.jpg" alt="003" style="width:60% ; margin-left:20%;margin-right:20%;">
     </div> 
     <div>
    <img src="../images/009.jpg" alt="003" style="width:60% ; margin-left:20%;margin-right:20%;">
     </div> 
     <div>
    <img src="../images/010.jpg" alt="003" style="width:60% ; margin-left:20%;margin-right:20%;">
     </div> 
     <div class="aaa">
    <button type="button" class="btn btn-outline-primary"><a href="./"><-Chap trước</a></button>
    <button type="button" class="btn btn-outline-primary"><a href="./">Chap sau-></a></button>
    </div>
 </body>
</html>